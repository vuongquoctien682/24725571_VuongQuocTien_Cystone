# Task 2 — K-Means cấp khách hàng

Cài môi trường thống nhất bằng `python -m pip install -r requirements-analysis.txt`, sau đó chạy toàn bộ `notebooks/07_kmeans.ipynb`, hoặc từ thư mục gốc:

```bash
python scripts/run_notebooks.py --notebook 07_kmeans.ipynb
```

Không cần xóa dữ liệu hay model trước khi chạy. Notebook dùng `data/final/cleaned_dataset.csv` và ghi lại kết quả của riêng bài toán phân cụm.

| Đường dẫn | Nội dung |
|---|---|
| `data/final/customer_segments.csv` | 1.988 hồ sơ khách hàng và nhãn cụm |
| `data/final/transactions_with_clusters.csv` | 10.000 giao dịch gắn nhãn khách hàng |
| `notebooks/figures/kmeans/` | Các hình lựa chọn K, phương sai PCA và cụm |
| `src/models/customer_kmeans_bundle.joblib` | Pipeline, ánh xạ nhãn, metadata đánh giá |

PCA ở cấp khách hàng giảm **4 → 3 chiều**, giữ **89,9281%** phương sai. Cả hai nhánh chọn **K=3**. Silhouette đo trên cùng không gian hành vi: non-PCA **0,278644**, PCA **0,277923**. Theo quy tắc chênh lệch không quá0,01 thì ưu tiên mô hình đơn giản, chọn **non-PCA**. Không dùng 9 thành phần của PCA cấp giao dịch làm đầu vào cho bài toán khách hàng.

```python
import joblib
from src.segmentation.customer_kmeans import predict_customers
bundle = joblib.load('src/models/customer_kmeans_bundle.joblib')
labels = predict_customers(bundle, customer_features)
```

`customer_features` phải chứa Recency, Frequency, Monetary, Mean_Discount_Ratio ở cấp khách hàng và cùng cửa sổ quan sát. Không truyền trực tiếp một dòng giao dịch. `predict_customers` ánh xạ nhãn đúng với CSV; nhãn được sắp theo trung vị chi tiêu tăng dần.

Dữ liệu là mô phỏng; cụm chưa tách biệt mạnh. Không suy ra phân khúc tự nhiên hoặc tác động kinh doanh thực tế chỉ từ kết quả này.
