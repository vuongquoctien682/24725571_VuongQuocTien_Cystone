"""Import MongoDB without interactive prompts or embedded Atlas credentials.

Usage from project root: python -m src.database.load_mongodb
Optional MONGODB_URI and MONGODB_DATABASE environment variables select a server.
"""
import json
from src.database.storage import ingest_mongodb

if __name__ == "__main__":
    print(json.dumps(ingest_mongodb(), ensure_ascii=False, indent=2))
