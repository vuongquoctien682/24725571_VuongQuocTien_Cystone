"""Initialize both databases before starting the web UI in Docker."""
import json
import os
import sys

from src.database.storage import ingest_all


def main():
    result = ingest_all()
    print("Database round-trip validation:", json.dumps(result, ensure_ascii=False), flush=True)
    os.execv(sys.executable, [sys.executable, "-m", "streamlit", "run", "app.py",
                             "--server.address=0.0.0.0", "--server.port=8501",
                             "--server.headless=true"])


if __name__ == "__main__":
    main()
