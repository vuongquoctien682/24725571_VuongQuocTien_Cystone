# Hai loại cơ sở dữ liệu của bản sửa

Luồng mặc định dùng SQLite (SQL) và MongoDB, phù hợp Windows/Linux/macOS và không cần tài khoản Atlas hay SQL Server cục bộ.

Từ thư mục gốc:

```bash
# Toàn bộ app + MongoDB, có nạp và kiểm tra đọc ngược tự động:
docker compose up --build

# Chỉ MongoDB, cho notebook 04 chạy trực tiếp trên máy:
docker compose -f docker-compose.yml -f docker-compose.notebook.yml up -d mongodb
python -m src.database.storage
```

Python cần `requirements.txt`; chạy notebook cần `requirements-analysis.txt`. Có thể dùng `docker-compose` nếu máy cài Compose dạng lệnh cũ.

- `MONGODB_URI`: mặc định `mongodb://127.0.0.1:27017` ngoài Docker, Compose tự dùng `mongodb://mongodb:27017`.
- `MONGODB_DATABASE`: mặc định `nhom11_retail`.
- `SQLITE_PATH`: mặc định `data/database/retail.db`, trong container `/app/data/database/retail.db`.
- Không commit URI có tài khoản/mật khẩu. Notebook không yêu cầu nhập hoặc lưu secret.
- Compose chỉ xuất cổng app ở loopback. Override cho notebook chỉ xuất MongoDB ở loopback. Cấu hình không xác thực này dành cho demo cục bộ; không xuất MongoDB công khai.
- SQL và MongoDB lưu snapshot theo SHA256 của `master_dataset.csv`; chạy lại không tạo giao dịch trùng và không xóa snapshot khác.
- Hàm đọc trả DataFrame; kiểm tra đối chiếu toàn bộ giá trị và missing values. Xem `report/validation/database_roundtrip.json` và output `04_database.ipynb`.
- `docker compose down` giữ lại cả volume SQL và MongoDB. Không dùng `down -v` nếu muốn giữ dữ liệu.

## SQL Server cũ (tùy chọn, không phải luồng mặc định đã kiểm thử)

`create_tables.sql` và `load_sqlserver.py` được giữ để tham khảo môi trường SQL Server của nhóm. Nhánh này cần SQL Server, ODBC Driver 17, `pyodbc` và thông tin kết nối phù hợp; không được chạy tự động bởi Compose. Kết quả kiểm thử mới của bản sửa là SQLite + MongoDB, không phải xác nhận lại SQL Server trên máy Windows cũ.
