"""Portable SQL + MongoDB round trips for the project's integrated dataset.

Each CSV revision gets its own table/collection. Re-running the import is
idempotent and never drops collections or unrelated user data.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
from pathlib import Path

import pandas as pd
from pandas.testing import assert_frame_equal
from pymongo import MongoClient, ReplaceOne

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_CSV = ROOT / "data/final/master_dataset.csv"


def _csv_path(csv_path=None) -> Path:
    return Path(csv_path) if csv_path is not None else DEFAULT_CSV


def _snapshot(csv_path=None) -> str:
    return "transactions_" + hashlib.sha256(_csv_path(csv_path).read_bytes()).hexdigest()[:16]


def _sqlite_path(sqlite_path=None) -> Path:
    return Path(sqlite_path or os.environ.get("SQLITE_PATH", ROOT / "data/database/retail.db"))


def _mongo_client() -> MongoClient:
    # No URI/password is written to logs or notebook outputs.
    return MongoClient(os.environ.get("MONGODB_URI", "mongodb://127.0.0.1:27017"),
                       serverSelectionTimeoutMS=10000, connectTimeoutMS=10000)


def _mongo_db() -> str:
    return os.environ.get("MONGODB_DATABASE", "nhom11_retail")


def load_source(csv_path=None) -> pd.DataFrame:
    df = pd.read_csv(_csv_path(csv_path), low_memory=False)
    if df.empty or "Transaction_ID" not in df:
        raise ValueError("Dataset must contain transactions and Transaction_ID")
    if df["Transaction_ID"].isna().any() or not df["Transaction_ID"].is_unique:
        raise ValueError("Transaction_ID must be non-null and unique")
    return df


def assert_round_trip(source: pd.DataFrame, restored: pd.DataFrame) -> None:
    """Check every value, column, ID, missing value and row after reading back."""
    if set(source.columns) != set(restored.columns):
        raise AssertionError("Database columns do not match the source CSV")
    expected = source.sort_values("Transaction_ID").reset_index(drop=True)
    actual = restored[source.columns].sort_values("Transaction_ID").reset_index(drop=True)
    assert_frame_equal(expected, actual, check_dtype=False, check_exact=False,
                       rtol=1e-12, atol=1e-8)


def read_sqlite(csv_path=None, sqlite_path=None, limit: int | None = None) -> pd.DataFrame:
    path = _sqlite_path(sqlite_path)
    if not path.is_file():
        raise FileNotFoundError("SQL database is not initialized. Run python -m src.database.storage")
    table = _snapshot(csv_path)  # identifier generated solely from SHA256
    query = f'SELECT * FROM "{table}" ORDER BY Transaction_ID'
    params = ()
    if limit is not None:
        if limit <= 0:
            raise ValueError("limit must be positive")
        query += " LIMIT ?"
        params = (int(limit),)
    with sqlite3.connect(path) as conn:
        return pd.read_sql_query(query, conn, params=params)


def read_mongodb(csv_path=None, limit: int | None = None) -> pd.DataFrame:
    with _mongo_client() as client:
        collection = client[_mongo_db()][_snapshot(csv_path)]
        cursor = collection.find({}, {"_id": 0}).sort("Transaction_ID", 1)
        if limit is not None:
            if limit <= 0:
                raise ValueError("limit must be positive")
            cursor = cursor.limit(int(limit))
        records = list(cursor)
    columns = pd.read_csv(_csv_path(csv_path), nrows=0).columns
    return pd.DataFrame(records, columns=columns)


def ingest_sqlite(csv_path=None, sqlite_path=None) -> dict:
    df = load_source(csv_path)
    path = _sqlite_path(sqlite_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    table = _snapshot(csv_path)
    with sqlite3.connect(path) as conn:
        exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
        if not exists:
            df.to_sql(table, conn, if_exists="fail", index=False, chunksize=500)
            conn.execute(f'CREATE UNIQUE INDEX "{table}_id" ON "{table}" (Transaction_ID)')
    restored = read_sqlite(csv_path, sqlite_path)
    assert_round_trip(df, restored)
    return {"database": "SQLite (SQL)", "rows": len(restored), "columns": len(restored.columns),
            "snapshot": table, "round_trip": "passed"}


def ingest_mongodb(csv_path=None) -> dict:
    df = load_source(csv_path)
    records = df.astype(object).where(df.notna(), None).to_dict("records")
    with _mongo_client() as client:
        client.admin.command("ping")
        collection = client[_mongo_db()][_snapshot(csv_path)]
        for start in range(0, len(records), 500):
            operations = []
            for original in records[start:start + 500]:
                record = {**original, "_id": str(original["Transaction_ID"])}
                operations.append(ReplaceOne({"_id": record["_id"]}, record, upsert=True))
            collection.bulk_write(operations, ordered=False)
    restored = read_mongodb(csv_path)
    assert_round_trip(df, restored)
    return {"database": "MongoDB", "rows": len(restored), "columns": len(restored.columns),
            "snapshot": _snapshot(csv_path), "round_trip": "passed"}


def ingest_all(csv_path=None, sqlite_path=None) -> dict:
    return {"sqlite": ingest_sqlite(csv_path, sqlite_path), "mongodb": ingest_mongodb(csv_path)}


def get_database_summary(csv_path=None, sqlite_path=None) -> dict:
    """Live read-only status for UI, including row counts in both stores."""
    table = _snapshot(csv_path)
    source_rows = len(load_source(csv_path))
    path = _sqlite_path(sqlite_path)
    if not path.is_file():
        raise FileNotFoundError("SQL database is not initialized")
    with sqlite3.connect(path) as conn:
        sql_count = conn.execute(f'SELECT COUNT(*) FROM "{table}"').fetchone()[0]
    with _mongo_client() as client:
        client.admin.command("ping")
        mongo_count = client[_mongo_db()][table].count_documents({})
    return {"snapshot": table, "source_rows": source_rows,
            "sqlite_rows": sql_count, "mongodb_rows": mongo_count,
            "counts_match": sql_count == mongo_count == source_rows}


def main():
    parser = argparse.ArgumentParser(description="Ingest CSV into SQL and MongoDB; verify full read-back")
    parser.add_argument("--csv", type=Path, default=DEFAULT_CSV)
    parser.add_argument("--sqlite-only", action="store_true")
    args = parser.parse_args()
    result = ingest_sqlite(args.csv) if args.sqlite_only else ingest_all(args.csv)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
