# Phân tích dữ liệu bán lẻ & thương mại điện tử — Nhóm 11

Dự án học phần Nhập môn Phân tích Dữ liệu & AI. Dữ liệu sản phẩm Tesco/Tiki là nguồn công khai; giao dịch, khách hàng và Rating là mô phỏng. Kết quả minh họa quy trình kỹ thuật, không chứng minh nhu cầu thị trường hay tác động nhân quả.

## Chạy ứng dụng bằng Docker

Cần Docker Engine/Desktop đang chạy và Docker Compose v2. Mở terminal tại thư mục chứa file này:

```bash
docker compose up --build
```

Sau khi khởi tạo thành công, mở `http://localhost:8501`. Bản Compose cũ có thể dùng `docker-compose up --build` nếu tương thích. App có PCA, K-Means, Regression, Classification và Database. Tab Database đọc mẫu trực tiếp từ **SQLite (SQL)** và **MongoDB**, đồng thời đối chiếu số dòng. Bước khởi động tự ghi/đọc lại toàn bộ dữ liệu và xác nhận khớp trước khi phục vụ UI. Không cần tài khoản cloud hay mật khẩu mẫu.

```bash
docker compose ps
docker compose logs app
docker compose down
```

Compose tách Web App và MongoDB thành hai container trên mạng riêng. SQLite và MongoDB có volume lưu dữ liệu. `down` giữ volume; không cần `down -v` để chạy lại. Các model đã được huấn luyện và có sẵn trong `src/models/`; ứng dụng không huấn luyện lại khi mở trang.

## Chạy Python / notebook

Dùng **Python 3.12**. Mọi model đã được xuất lại với **scikit-learn 1.8.0**, thống nhất giữa ứng dụng và notebook.

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# Linux/macOS: source .venv/bin/activate
python -m pip install -r requirements-analysis.txt
python scripts/run_notebooks.py
python scripts/validate_app.py
python -m streamlit run app.py
```

Chọn interpreter/kernel của `.venv` khi mở notebook bằng VS Code hoặc Jupyter. `run_notebooks.py` dùng chính Python đang gọi script; thực thi lần lượt 03 → 05 → 06 → 07 → 08 → 09 và ghi lại outputs thật. Notebook 01–02 kiểm tra/chuẩn hóa nguồn đã đính kèm; không bắt buộc sinh lại giao dịch để tái hiện mô hình. Không dùng file model pickle từ nguồn không tin cậy.

Nếu muốn chạy cả notebook CSDL bên ngoài Docker, phải có MongoDB đang chạy, cấu hình `MONGODB_URI`, rồi:

```bash
python -m src.database.storage
python scripts/run_notebooks.py --include-database
```

`MONGODB_URI` mặc định dùng MongoDB local; `MONGODB_DATABASE` và `SQLITE_PATH` có thể điều chỉnh qua biến môi trường. Không đưa URI chứa mật khẩu vào notebook, Git hoặc ảnh báo cáo. Các script SQL Server cũ chỉ là lựa chọn bổ sung, không thuộc luồng Docker mặc định; xem hướng dẫn trong `src/database/`.

## Quy trình và minh chứng rubric

| Nội dung | File chính |
|---|---|
| Nguồn dữ liệu, chuẩn hóa schema | `notebooks/01 static data 1.ipynb`, `01 static data 2.ipynb` |
| Dữ liệu động, ngân hàng nhận xét | `notebooks/02_dynamic_data.ipynb`, `src/data_generation/` |
| `pd.concat`, `pd.merge`, kiểm tra khóa và số dòng | `notebooks/03_data_integration.ipynb` |
| SQL + MongoDB, ghi và đọc lại DataFrame | `notebooks/04_database.ipynb`, `src/database/storage.py` |
| Missing values, IQR/Z-score, EDA và insight | `notebooks/05_cleaning_eda.ipynb` |
| PCA cấp giao dịch | `notebooks/06_pca.ipynb` |
| K-Means gốc và sau giảm chiều | `notebooks/07_kmeans.ipynb`, `src/segmentation/customer_kmeans.py` |
| Linear Regression và Decision Tree Regressor | `notebooks/08_regression.ipynb` |
| Logistic Regression và Decision Tree Classifier | `notebooks/09_classification.ipynb` |
| Giao diện, triển khai | `app.py`, `Dockerfile`, `docker-compose.yml` |
| Báo cáo đã cập nhật | `report/Nhom11_FinalProject.docx` |
| Đối chiếu rubric, kết quả kiểm tra | `report/DOI_CHIEU_RUBRIC.md`, `report/validation/` |

Dữ liệu `data/raw/` được giữ nguyên. `data/processed/` chứa nguồn chuẩn hóa và 10.000 giao dịch đã sinh. `data/final/master_dataset.csv` là dữ liệu tích hợp trước làm sạch; `cleaned_dataset.csv` là dữ liệu phân tích. Kết quả sau khi chạy lại có thể khác bản báo cáo cũ vì lỗi hoặc cách đánh giá đã được sửa; dùng bảng/ảnh và ghi chú của bản này, không chép lại số cũ.

## Nguồn và giới hạn dữ liệu AI

- Tiki: https://www.kaggle.com/datasets/michaelminhpham/vietnamese-tiki-e-commerce-dataset
- Tesco: https://huggingface.co/datasets/crawlfeeds/tesco-grocery-uk
- Nguồn đầu vào, link và quy trình được ghi trong notebook. Ngân hàng nhận xét hiện có được tái sử dụng để giữ nguyên dữ liệu. Chỉ khi chủ động muốn sinh lại văn bản mới cần cài/chạy Ollama và tải `qwen3:1.7b`; việc đó có thể thay đổi đầu vào và yêu cầu chạy lại toàn bộ pipeline. Bản kiểm tra này không xác nhận có bao nhiêu nhận xét cũ thực sự do LLM sinh thay vì dùng câu dự phòng.
- Rating được sinh ngẫu nhiên nên các đặc trưng hiện có không có tín hiệu dự báo hài lòng đáng tin cậy. So sánh với baseline lớp đa số, không gọi accuracy quanh 50% là hiệu quả kinh doanh.
- Hồi quy Revenue chủ yếu học quan hệ cơ học từ cách mô phỏng doanh thu; không dùng như bằng chứng điều chỉnh giá sẽ làm tăng nhu cầu.

## Thành viên

Hà Xuân Khoa; Vương Quốc Tiến; Nguyễn Tuấn Duy; Phan Chí Thanh; Nguyễn Huỳnh Thanh Tuấn; Nguyễn Vương Quốc Tuấn.
