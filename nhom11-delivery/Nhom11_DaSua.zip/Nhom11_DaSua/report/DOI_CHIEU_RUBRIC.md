# Đối chiếu rubric sau chỉnh sửa

Kiểm tra ngày 03/11/2026 trên dữ liệu trong ZIP. Đây là bảng minh chứng, không phải dự đoán điểm chấm.

| Tiêu chí | Minh chứng trong bản sửa | Trạng thái / giới hạn |
|---|---|---|
| Nguồn dữ liệu, link nguồn đầu code | Notebook01a/01b và script quy đổi có URL; Tesco1.200 dòng, Tiki5.361 dòng trước deduplicate | Nguồn gốc có chú thích. Không crawl mới; dùng nhánh dữ liệu AI synthetic + dữ liệu tĩnh |
| AI synthetic text | Script Ollama qwen3:1.7b + review_bank.json100 câu; notebook02 kiểm tra10.000 giao dịch frozen | Không gọi lại LLM trong lần sửa; chưa xác minh tỷ lệ câu lịch sử do LLM tạo so với fallback. Khi cần minh chứng sinh AI, chạy script với Ollama thật và lưu log, sau đó tái chạy pipeline nếu đổi dữ liệu |
| Concat, merge, loại Join | Notebook03:concat; left merge many_to_one; kiểm tra khóa, số dòng/thứ tự/giá | Đã chạy. Catalogue6.559 khác pool có giá6.556; không nhầm hai số |
| Hai loại CSDL, ghi/đọc Python | Notebook04, storage.py, tab Database; SQLite(SQL)+MongoDB | Đã chạy thật,10.000×39 từng CSDL; read-back so khớp từng giá trị; import lại không nhân bản. SQLServer cũ là tùy chọn, không xác nhận đã kiểm thử |
| Missing values | Notebook05 và validation/eda: % trước/sau, missingno, phân tách theo nguồn, imputation log, before/after | Không bịa median cho cột khuyết cấu trúc.10 Category thiếu →Unknown; số ô số cần impute trong nguồn hiện tại là0; giữ NaN đúng bản chất |
| Descriptive stats/outlier | Mean/median/std/skewness/excess-kurtosis, IQR và Z-score; biểu đồ và bảng | Có kiểm tra. Giữ cap10 Revenue theo benchmark cũ; cap tính toàn dữ liệu là giới hạn, không coi như benchmark sản xuất độc lập |
| Đa biến | Pearson/Spearman, scatter, boxplot theo Rating, crosstab Source×Rating | Đã chạy; biểu đồ/tables xuất kèm |
| ≥5 biểu đồ và insight | Notebook05 có Histogram+KDE, Boxplot, heatmap, Scatter, stacked bar và Markdown gắn Stage2; báo cáo mục1.4 | Đã bổ sung/minh họa bằng kết quả thật |
| PCA/K-Means | Notebook06:11→9,91,44%; notebook07:4→3,89,9281%,so với nonPCA; Elbow/Silhouette,plot,Cluster_Label | Đã huấn luyện lại; nonPCA K3 được chọn bằng quy tắc đơn giản/tolerance; không dùng9PC giao dịch cho khách hàng |
| Regression | Notebook08:Linear vs DecisionTree,train/validation/test,MSE/RMSE/R²,Actual vs Predicted | Linear chọn theo validation; R² test0,8139285; RMSE2.413.807,62VND; file xuất đúng regression_model.joblib |
| Classification | Notebook09:LR vs DecisionTree,class_weight balanced,reports đầy đủ2 lớp,confusion heatmaps,baseline | LR chọn theo validation; test LR47,45%,tree50,75%,majority59,5%. Không chọn lại model theo test, không hứa hiệu quả thực tế |
| UI ba đầu ra + biểu đồ | App có4 tab mô hình và tab Database | AppTest + Chromium trên Docker:4 inference và đọc DB đều đạt; PCA đúng9 tọa độ |
| Docker đa container | Dockerfile,compose,healthcheck,network,2 volumes,startup ingest+validate | Build và chạy thật; app+mongodb healthy; screenshot mới và log trong validation |
| Báo cáo/khuyến nghị | Nhom11_FinalProject.docx bổ sung1.4, sửa2.1.3,2.2,3.1 và số liệu liên quan | Giữ các khuyến nghị kinh doanh dưới dạng giả thuyết cần kiểm chứng trên dữ liệu thực |

## Trước khi nộp

1. Mở DOCX bằng Word, cập nhật mục lục và rà lại ngắt trang/cách hiển thị bảng theo mẫu của lớp. Nội dung/XML và liên kết ảnh đã kiểm tra; không xuất PDF để kiểm chứng bố cục in trên máy người nhận.
2. Chạy `docker compose up --build` trên máy thuyết trình và thử các tab; xem README về môi trường Python3.12.
3. Không dùng lại các ảnh và số liệu cũ (PCA11 tọa độ, phân cụm4/4, regressionR²0,8095, tree50,80%).
4. Chưa có slide trong ZIP; nếu giảng viên yêu cầu nộp slide riêng, chuẩn bị từ bản báo cáo mới.
5. Nếu yêu cầu minh chứng LLM tạo text ở mức thực thi, bổ sung log Ollama thật; bản sửa không tạo bằng chứng giả cho bước này.
