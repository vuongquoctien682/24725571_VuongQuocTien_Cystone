"""Exercise the shipped Streamlit app and model artifacts, without retraining."""
import json
import sys
from pathlib import Path
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
app = AppTest.from_file(str(ROOT / 'app.py'), default_timeout=60)
app.run()
assert not app.exception, app.exception
results = {}
for label in ['Tính các thành phần PCA', 'Xác định phân khúc', 'Dự đoán doanh thu', 'Dự đoán Rating']:
    button = next(b for b in app.button if b.label == label)
    button.click().run()
    assert not app.exception, app.exception
    if label == 'Tính các thành phần PCA':
        coords = app.dataframe[0].value
        assert len(coords) == 9, f'Expected reduced PCA with 9 rows, got {len(coords)}'
        assert coords['Giá trị'].notna().all()
        results['pca_components'] = len(coords)
    elif label == 'Xác định phân khúc':
        assert any('Phân khúc dự đoán' in x.value for x in app.success)
    elif label == 'Dự đoán doanh thu':
        assert any(x.label == 'Doanh thu dự đoán' for x in app.metric)
    else:
        assert any('Mô hình dự đoán' in x.value for x in [*app.info, *app.success])
    results[label] = 'passed'
out = ROOT / 'report/validation'
out.mkdir(parents=True, exist_ok=True)
(out / 'app_smoke.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(results, ensure_ascii=False, indent=2))
