"""Re-run analysis using this Python environment and the supplied source data.

Does not regenerate synthetic transactions/reviews. DB notebook requires MongoDB
and is invoked explicitly with --include-database.
"""
import argparse
import json
import os
from pathlib import Path
import sys
from datetime import datetime, timezone
import nbformat
from nbclient import NotebookClient
from jupyter_client import KernelManager

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument('--include-database', action='store_true')
parser.add_argument('--notebook', action='append', help='Run only a specified notebook basename; may repeat')
args = parser.parse_args()
names = ['03_data_integration.ipynb', '05_cleaning_eda.ipynb', '06_pca.ipynb',
         '07_kmeans.ipynb', '08_regression.ipynb', '09_classification.ipynb']
if args.include_database:
    names.insert(1, '04_database.ipynb')
if args.notebook:
    allowed = {p.name for p in (ROOT / 'notebooks').glob('*.ipynb')}
    if not set(args.notebook) <= allowed:
        parser.error('--notebook must name an existing notebook in notebooks/')
    names = args.notebook
for key in ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']:
    os.environ.setdefault(key, '2')
results = {'started_utc': datetime.now(timezone.utc).isoformat(), 'notebooks': []}
output = ROOT / 'report/validation/notebook_run.json'
output.parent.mkdir(parents=True, exist_ok=True)
for name in names:
    path = ROOT / 'notebooks' / name
    nb = nbformat.read(path, as_version=4)
    km = KernelManager(kernel_name='python3')
    km.kernel_spec.argv = [sys.executable, '-m', 'ipykernel_launcher', '-f', '{connection_file}']
    client = NotebookClient(nb, km=km, timeout=900, resources={'metadata': {'path': str(ROOT)}})
    try:
        client.execute()
        nbformat.write(nb, path)
        results['notebooks'].append({'name': name, 'status': 'passed'})
        print(f'PASS {name}', flush=True)
    except Exception:
        results['notebooks'].append({'name': name, 'status': 'failed'})
        output.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
        raise
    finally:
        # A supplied KernelManager is owned by this caller.
        if km.has_kernel:
            km.shutdown_kernel(now=True)
    output.write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
