**Mô hình được chọn bằng validation: Logistic Regression.**

| Mô hình | Test Accuracy | Recall lớp 1 | Macro-F1 |
|---|---:|---:|---:|
| Logistic Regression | 47.45% | 52.72% | 0.4733 |
| Decision Tree | 50.75% | 43.83% | 0.4958 |
| Majority baseline | 59.50% | 0.00% | 0.3730 |

Baseline đa số bỏ sót toàn bộ lớp 1. Class weighting có thể tăng Recall lớp 1 nhưng không bảo đảm Accuracy cao hơn baseline. Kết quả phải được đọc theo mục tiêu bài toán.

Rating được sinh ngẫu nhiên độc lập trong chương trình mô phỏng; review lại được chọn theo Rating. Vì vậy không diễn giải các chỉ số này thành khả năng dự báo hài lòng khách hàng thật và không thêm review vào đầu vào để làm tăng điểm số.

Ảnh hưởng tới Stage 2: giữ hai thuật toán theo yêu cầu để minh họa quy trình; dùng class_weight để xử lý tỷ lệ lớp; muốn triển khai kinh doanh cần dữ liệu Rating thật và đánh giá theo khách hàng/thời gian độc lập. Xác suất predict_proba chưa được hiệu chuẩn.

Giới hạn: dữ liệu đầu vào đã được làm sạch/khảo sát ở Stage 1, và bộ test này đã từng được xem trong phiên bản cũ. Quy trình mới tách test khỏi lựa chọn mô hình trong lần chạy này, nhưng không biến nó thành một tập đánh giá hoàn toàn mới. Muốn ước lượng tổng quát độc lập cần dữ liệu mới chưa từng dùng trong thiết kế và tiền xử lý.